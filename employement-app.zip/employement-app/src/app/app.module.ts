import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
// Forms module
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';


import { AppComponent } from './app.component';
import { EmployeeCreateComponent } from './users/employee-create/employee-create.component';
import { EmployeeEditComponent } from './users/employee-edit/employee-edit.component';
import { EmployeesListComponent } from './users/employees-list/employees-list.component';
import { SortDirective } from './directive/sort.directive';
import { EmployeeViewComponent } from './users/employee-view/employee-view.component';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeCreateComponent,
    EmployeeEditComponent,
    EmployeesListComponent,
    SortDirective,
    EmployeeViewComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
