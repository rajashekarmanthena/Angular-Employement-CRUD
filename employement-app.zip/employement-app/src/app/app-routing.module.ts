import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeCreateComponent } from './users/employee-create/employee-create.component';
import { EmployeeEditComponent } from './users/employee-edit/employee-edit.component';
import { EmployeesListComponent } from './users/employees-list/employees-list.component';
import { EmployeeViewComponent } from './users/employee-view/employee-view.component';


const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'employees-list' },
  { path: 'create-employee', component: EmployeeCreateComponent },
  { path: 'employees-list', component: EmployeesListComponent },
  { path: 'employee-edit/:id', component: EmployeeEditComponent },
  { path: 'employee-view/:id', component: EmployeeViewComponent } 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
