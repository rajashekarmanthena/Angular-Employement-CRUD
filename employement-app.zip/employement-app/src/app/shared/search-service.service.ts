import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, interval } from 'rxjs';
import { map, debounceTime, distinctUntilChanged } from "rxjs/operators";
import { switchMap } from 'rxjs/operators/switchMap';
import 'rxjs/Rx';

@Injectable({
  providedIn: 'root'
})
export class SearchServiceService {
  baseUrl: string = 'http://localhost:3000/employees';
  queryUrl: string = '?search=';

  constructor(private http: HttpClient) { }

  search(terms: Observable<string>) {
    debugger;
    return terms.pipe(debounceTime(400),
      distinctUntilChanged(),
      switchMap(() => interval(50), term => this.searchEntries(term)));
  }

  searchEntries(term) {
    this.http.get(this.baseUrl + this.queryUrl + term).pipe(map(res => {
      console.log(res);
    }))
  }
  
}
