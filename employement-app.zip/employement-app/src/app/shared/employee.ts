export class Employee {
    id: number;
    name: string;
    age: number;
    department: string;
}
