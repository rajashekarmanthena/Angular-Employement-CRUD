import { Component, ViewChild, ElementRef, OnInit } from '@angular/core';
import { RestApiService } from "../../shared/rest-api.service";
import { HttpClient } from '@angular/common/http';
import { SearchServiceService } from '../../shared/search-service.service';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-employees-list',
  templateUrl: './employees-list.component.html',
  styleUrls: ['./employees-list.component.css'],
  providers: [SearchServiceService]
})
export class EmployeesListComponent implements OnInit {
   results: any;
   searchTerm$ = new Subject<string>();
   Employee: any = [];

   
  constructor(public restApi: RestApiService,private http: HttpClient,private searchService: SearchServiceService) { 
    this.Employee = [];
    this.searchService.search(this.searchTerm$)
      .subscribe(result => {
        this.results = result;
      });
  }

  ngOnInit() {
    this.loadEmployees()

  }
  
 

   // Get employees list
  loadEmployees() {
    return this.restApi.getEmployees().subscribe(response => {
      this.Employee = response;
    })
  }

  // Delete employee
  deleteEmployee(item) {
    if (window.confirm('Are you sure, you want to delete?')){
      this.restApi.deleteEmployee(item.id).subscribe(response => {
        console.log(response);
        this.loadEmployees()
      })
    }
  }  
  


}
