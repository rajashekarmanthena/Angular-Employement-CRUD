import { Component, OnInit } from '@angular/core';
import { Employee } from '../../shared/employee'
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { RestApiService } from "../../shared/rest-api.service";


@Component({
  selector: 'app-employee-create',
  templateUrl: './employee-create.component.html',
  styleUrls: ['./employee-create.component.css']
})
export class EmployeeCreateComponent implements OnInit {
  employeeForm: FormGroup;
  data: Employee;

  constructor(public fb: FormBuilder,public restApi: RestApiService, public router: Router) { 
    this.data = new Employee();
  }

  ngOnInit() {
    this.employeeForm = this.fb.group({
      id: [''],
      name: ['', Validators.required],
      age: ['', Validators.required],
      department: [''],    
    })
  }

  addEmployee() {
    debugger;
    this.restApi.createEmployee(this.data).subscribe((response) => {
      this.router.navigate(['employees-list'])
    })
  }
  

}
