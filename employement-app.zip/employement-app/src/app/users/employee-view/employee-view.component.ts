import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../../shared/employee'
import { RestApiService } from "../../shared/rest-api.service";


@Component({
  selector: 'app-employee-view',
  templateUrl: './employee-view.component.html',
  styleUrls: ['./employee-view.component.css']
})
export class EmployeeViewComponent implements OnInit {

   id = 'number';
   data: Employee;

  constructor(public restApi: RestApiService,public actRoute: ActivatedRoute,public router: Router) { }

  ngOnInit() {
    this.id = this.actRoute.snapshot.params["id"];
    // get employee details using id
    this.restApi.getEmployee(this.id).subscribe(response => {
      console.log(response);
      debugger;
      this.data = response;
    })
  }

}
