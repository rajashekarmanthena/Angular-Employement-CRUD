import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../../shared/employee'
import { RestApiService } from "../../shared/rest-api.service";



@Component({
  selector: 'app-employee-edit',
  templateUrl: './employee-edit.component.html',
  styleUrls: ['./employee-edit.component.css']
})
export class EmployeeEditComponent implements OnInit {

   id = 'number';
   data: Employee;

  constructor(public restApi: RestApiService,public actRoute: ActivatedRoute,public router: Router) { }

  ngOnInit() {
    this.id = this.actRoute.snapshot.params["id"];
    // get employee details using id
    this.restApi.getEmployee(this.id).subscribe(response => {
      console.log(response);
      this.data = response;
    })
  }

  // Update employee data
  updateEmployee() {

    if(window.confirm('Are you sure, you want to update?')){
      this.restApi.updateEmployee(this.id, this.data).subscribe(response => {
        this.router.navigate(['employees-list'])
      })
    }
  }


}
